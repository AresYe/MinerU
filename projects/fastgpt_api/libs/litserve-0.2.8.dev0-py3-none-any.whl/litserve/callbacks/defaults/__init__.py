from litserve.callbacks.defaults.metric_callback import PredictionTimeLogger

__all__ = ["PredictionTimeLogger"]
