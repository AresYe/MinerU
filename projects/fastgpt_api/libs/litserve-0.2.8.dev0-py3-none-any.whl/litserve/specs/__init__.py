from litserve.specs.openai import OpenAISpec
from litserve.specs.openai_embedding import OpenAIEmbeddingSpec

__all__ = ["OpenAISpec", "OpenAIEmbeddingSpec"]
